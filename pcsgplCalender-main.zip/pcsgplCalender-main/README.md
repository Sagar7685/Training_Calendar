# pcsgplCalender

Calendar Project to schedule Trainings across India.

Admins can delete trainings sessions

Trainers can schedule training and delete their own trainings

Other Users can only view the trains

The view page is paginated

Role based access to the Portal

Users have to authenticate to view,edit,schedule and delete training sessions
