package com.pcsgpl.tc.controller;

import org.springframework.web.bind.annotation.GetMapping;

public class MeetingCalenderRestController {
	
}
